import React, { Component } from 'react';
//import Button from './component/Button';
import StyledButton from './component/StyledButton/StyledButton';

//import classNames from 'classnames/bind';
//import styles from './App.scss';
//const cx = classNames.bind(styles);



class App extends Component {
  render() {
    /*
    const isBlue = true;
    
    return (
      <div className={ cx('box',{
        blue : isBlue
      }) }>

      </div>
    );

    return (
      <div className={ cx('box','blue') }>

      </div>
    );

    */
   /*
    return (
      <div>
        <Button>버튼</Button>
      </div>
   );*/
   return (
    <div>
      <StyledButton test="test" big>버튼</StyledButton>
    </div>
  );
  }
}

export default App;


/*
  2019/03/04
  
  내가 참고하고 있는 
  "리액트를 다루는 기술" 이라는 책에 css-loader 옵션 설정부가 약간 다른점이 있어서
  삽질 끝에 코멘트 남긴다.

  1) 
  9.1.1. CSS Module 활성화 절에서 
  config/webpack.config.dev.js라고 되어 있는데
  현시점은 
  config/webpack.config.js이다.
  
  2) 
  1번에 이어서... 코드 내용을 보면 현재 config/webpack.config.js의 파일 내용 구성과 많이 다르다.
  (책 출판시에는 ES5 방식이었는데 현재 코드들을 보면 ES6방식으로 컨버팅 된것같다.)

  책에서 modules, localIdentName에 설정하는 부분은
  현재 config/webpack.config.js에서  ★부분에 추가하는 것으로 변경되었다. 하기 코드부분에서 ★를 참고한다.
  (책에서는 localIdentName라고 되어있는 멤버는 getLocalIdent로 변경된듯하다.)

  * webpack.config.js Line 392쯤

            // "postcss" loader applies autoprefixer to our CSS.
            // "css" loader resolves paths in CSS and adds assets as dependencies.
            // "style" loader turns CSS into JS modules that inject <style> tags.
            // In production, we use MiniCSSExtractPlugin to extract that CSS
            // to a file, but in development "style" loader enables hot editing
            // of CSS.
            // By default we support CSS Modules with the extension .module.css
            {
              test: cssRegex,
              exclude: cssModuleRegex,
              use: getStyleLoaders({
                importLoaders: 1,
                sourceMap: isEnvProduction
                  ? shouldUseSourceMap
                  : isEnvDevelopment,
                ★modules: true,
                ★getLocalIdent: '[path][name]__[local]--[hash:base64:5]', //getCSSModuleLocalIdent,
              }),
              // Don't consider CSS imports dead code even if the
              // containing package claims to have no side effects.
              // Remove this when webpack adds a warning or an error for this.
              // See https://github.com/webpack/webpack/issues/6571
              sideEffects: true,
            },



*/