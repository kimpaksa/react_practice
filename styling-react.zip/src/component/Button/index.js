import Button from './Button';
export default Button;

// 아래처럼 한줄로 쓸수도 있다.
// export  { default } from './Button';